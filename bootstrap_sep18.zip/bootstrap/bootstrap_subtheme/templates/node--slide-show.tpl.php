<?php
    print render($content['field_slideshow_image']);
	echo "hello slideshow";
?>
 